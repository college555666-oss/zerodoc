// Google Sheets API integration utilities
// Note: In a production app, you would need to set up OAuth2 authentication
// For this demo, we'll use a simplified approach with API keys

const SHEETS_API_BASE = 'https://sheets.googleapis.com/v4/spreadsheets'
// When running in the browser (Vite), environment variables are exposed via import.meta.env
const SPREADSHEET_ID = import.meta.env?.VITE_GOOGLE_SHEET_ID || ''
const API_KEY = import.meta.env?.VITE_GOOGLE_API_KEY || ''
const LOCAL_WORKFLOWS_KEY = 'workflows'
const LOCAL_FORM_DATA_KEY = 'formData'

let sheetsAvailable = Boolean(SPREADSHEET_ID && API_KEY)

const disableSheetsIntegration = (statusCode) => {
  if (!sheetsAvailable) return
  sheetsAvailable = false
  const reason = statusCode ? ` (status ${statusCode})` : ''
  console.warn(
    `Google Sheets integration disabled for this session${reason}. Falling back to local storage.`
  )
}

const generateId = () => {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID()
  }
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
}

const saveWorkflowLocally = (workflowData) => {
  const workflows = JSON.parse(localStorage.getItem(LOCAL_WORKFLOWS_KEY) || '[]')
  const workflow = {
    id: generateId(),
    ...workflowData,
    createdAt: new Date().toISOString()
  }
  workflows.push(workflow)
  localStorage.setItem(LOCAL_WORKFLOWS_KEY, JSON.stringify(workflows))
  return workflow
}

const getLocalWorkflows = () => {
  const workflows = JSON.parse(localStorage.getItem(LOCAL_WORKFLOWS_KEY) || '[]')
  return workflows.map((workflow) => ({
    ...workflow,
    id: workflow.id || generateId()
  }))
}

const saveFormDataLocally = (formData) => {
  const formDataList = JSON.parse(localStorage.getItem(LOCAL_FORM_DATA_KEY) || '[]')
  formDataList.push({
    timestamp: new Date().toISOString(),
    ...formData
  })
  localStorage.setItem(LOCAL_FORM_DATA_KEY, JSON.stringify(formDataList))
}

// In a real implementation, you would use OAuth2 for authentication
// This is a simplified version for demonstration

export const useSheets = () => {
  const saveWorkflow = async (workflowData) => {
    if (!sheetsAvailable) {
      if (!SPREADSHEET_ID || !API_KEY) {
        console.warn('Google Sheets env vars missing. Saving workflow locally.')
      }
      saveWorkflowLocally(workflowData)
      return { success: true, storage: 'local' }
    }

    try {
      // In production, use OAuth2 token instead of API key
      const response = await fetch(
        `${SHEETS_API_BASE}/${SPREADSHEET_ID}/values/Workflows:append?valueInputOption=RAW&key=${API_KEY}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            values: [[
              new Date().toISOString(),
              workflowData.name,
              workflowData.type,
              JSON.stringify(workflowData.steps),
              workflowData.status || 'active'
            ]]
          })
        }
      )

      if (!response.ok) {
        if ([400, 401, 403].includes(response.status)) {
          disableSheetsIntegration(response.status)
        }
        throw new Error('Failed to save workflow')
      }

      return await response.json()
    } catch (error) {
      console.error('Error saving workflow:', error)
      // Fallback to localStorage if API fails
      saveWorkflowLocally(workflowData)
      return { success: true }
    }
  }

  const getWorkflows = async () => {
    if (!sheetsAvailable) {
      if (!SPREADSHEET_ID || !API_KEY) {
        console.warn('Google Sheets env vars missing. Loading workflows from local storage.')
      }
      return getLocalWorkflows()
    }

    try {
      const response = await fetch(
        `${SHEETS_API_BASE}/${SPREADSHEET_ID}/values/Workflows?key=${API_KEY}`
      )

      if (!response.ok) {
        if ([400, 401, 403].includes(response.status)) {
          disableSheetsIntegration(response.status)
        }
        throw new Error('Failed to fetch workflows')
      }

      const data = await response.json()
      // Transform Google Sheets data format to our workflow format
      return data.values?.slice(1).map((row, index) => ({
        id: index.toString(),
        createdAt: row[0],
        name: row[1],
        type: row[2],
        steps: JSON.parse(row[3] || '[]'),
        status: row[4]
      })) || []
    } catch (error) {
      console.error('Error fetching workflows:', error)
      // Fallback to localStorage
      return getLocalWorkflows()
    }
  }

  const saveTemplateUsage = async (templateId) => {
    if (!sheetsAvailable) {
      if (!SPREADSHEET_ID || !API_KEY) {
        console.warn('Google Sheets env vars missing. Skipping template usage logging.')
      }
      return
    }

    try {
      const response = await fetch(
        `${SHEETS_API_BASE}/${SPREADSHEET_ID}/values/TemplateUsage:append?valueInputOption=RAW&key=${API_KEY}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            values: [[
              new Date().toISOString(),
              templateId
            ]]
          })
        }
      )
      if (!response.ok) {
        if ([400, 401, 403].includes(response.status)) {
          disableSheetsIntegration(response.status)
        }
        throw new Error('Failed to log template usage')
      }
    } catch (error) {
      console.error('Error saving template usage:', error)
      // Silently fail for analytics
    }
  }

  const saveFormData = async (formData) => {
    if (!sheetsAvailable) {
      if (!SPREADSHEET_ID || !API_KEY) {
        console.warn('Google Sheets env vars missing. Saving form data locally.')
      }
      saveFormDataLocally(formData)
      return
    }

    try {
      const response = await fetch(
        `${SHEETS_API_BASE}/${SPREADSHEET_ID}/values/FormData:append?valueInputOption=RAW&key=${API_KEY}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            values: [[
              new Date().toISOString(),
              ...Object.values(formData)
            ]]
          })
        }
      )
      if (!response.ok) {
        if ([400, 401, 403].includes(response.status)) {
          disableSheetsIntegration(response.status)
        }
        throw new Error('Failed to save form data')
      }
    } catch (error) {
      console.error('Error saving form data:', error)
      // Fallback to localStorage
      saveFormDataLocally(formData)
    }
  }

  return {
    saveWorkflow,
    getWorkflows,
    saveTemplateUsage,
    saveFormData
  }
}

