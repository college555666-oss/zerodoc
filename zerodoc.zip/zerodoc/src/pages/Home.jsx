import { Link } from 'react-router-dom'
import './Home.css'

function Home({ accessibilityMode }) {
  return (
    <div className="home">
      <section className="hero" aria-labelledby="hero-heading">
        <h1 id="hero-heading">ZeroCode Automate</h1>
        <p className="hero-subtitle">
          Automate web tasks without writing code. Built for accessibility and privacy.
        </p>
        <div className="hero-actions">
          <Link 
            to="/templates" 
            className="btn btn-primary"
            aria-label="Browse pre-made automation templates"
          >
            Browse Templates
          </Link>
          <Link 
            to="/wizard" 
            className="btn btn-secondary"
            aria-label="Create a new workflow using the step-by-step wizard"
          >
            Create Workflow
          </Link>
        </div>
      </section>

      <section className="features" aria-labelledby="features-heading">
        <h2 id="features-heading">Key Features</h2>
        <div className="features-grid">
          <div className="feature-card">
            <div className="feature-icon" aria-hidden="true">📋</div>
            <h3>Pre-Made Templates</h3>
            <p>Choose from ready-to-use automation templates for common workflows like form autofill and alerts.</p>
          </div>
          
          <div className="feature-card">
            <div className="feature-icon" aria-hidden="true">🧙</div>
            <h3>Step-by-Step Wizard</h3>
            <p>Create custom workflows with our accessible, screen-reader friendly wizard interface.</p>
          </div>
          
          <div className="feature-card">
            <div className="feature-icon" aria-hidden="true">♿</div>
            <h3>Accessibility First</h3>
            <p>Real-time feedback, keyboard navigation, and screen reader support built into every feature.</p>
          </div>
          
          <div className="feature-card">
            <div className="feature-icon" aria-hidden="true">🎤</div>
            <h3>Voice Commands</h3>
            <p>Control your automations with voice commands, making the platform accessible for motor disabilities.</p>
          </div>
          
          <div className="feature-card">
            <div className="feature-icon" aria-hidden="true">🔒</div>
            <h3>Privacy Mode</h3>
            <p>Take control of your data with privacy mode that limits data collection and storage.</p>
          </div>
          
          <div className="feature-card">
            <div className="feature-icon" aria-hidden="true">📊</div>
            <h3>Google Sheets Integration</h3>
            <p>Store and manage your workflow data securely in your own Google Sheets.</p>
          </div>
        </div>
      </section>

      {accessibilityMode && (
        <section className="accessibility-preview" aria-labelledby="a11y-preview-heading">
          <h2 id="a11y-preview-heading">Accessibility Mode Active</h2>
          <p>You're viewing the site in accessibility mode. All features are optimized for screen readers and keyboard navigation.</p>
        </section>
      )}

      <section className="getting-started" aria-labelledby="getting-started-heading">
        <h2 id="getting-started-heading">Getting Started</h2>
        <ol className="steps-list">
          <li>
            <strong>Choose a template</strong> or create a custom workflow using our wizard
          </li>
          <li>
            <strong>Customize your automation</strong> by answering simple questions
          </li>
          <li>
            <strong>Test and preview</strong> your workflow with accessibility mode
          </li>
          <li>
            <strong>Save and run</strong> your automation whenever you need it
          </li>
        </ol>
      </section>
    </div>
  )
}

export default Home

