import { useState, useEffect } from 'react'
import { useSheets } from '../utils/sheets'
import './Workflows.css'

function Workflows({ privacyMode }) {
  const [workflows, setWorkflows] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')
  const { getWorkflows } = useSheets()

  useEffect(() => {
    loadWorkflows()
  }, [])

  const loadWorkflows = async () => {
    setLoading(true)
    try {
      const data = await getWorkflows()
      setWorkflows(data)
    } catch (error) {
      console.error('Error loading workflows:', error)
    } finally {
      setLoading(false)
    }
  }

  const filteredWorkflows = workflows.filter(w => {
    if (filter === 'all') return true
    return w.status === filter
  })

  const handleExecute = (workflowId) => {
    // Trigger workflow execution
    const workflow = workflows.find(w => w.id === workflowId)
    if (workflow) {
      alert(`Executing workflow: ${workflow.name}`)
      // In a real implementation, this would trigger the automation
      window.dispatchEvent(new CustomEvent('executeWorkflow', { detail: workflow }))
    }
  }

  const handleDelete = async (workflowId) => {
    if (window.confirm('Are you sure you want to delete this workflow?')) {
      const updated = workflows.filter(w => w.id !== workflowId)
      setWorkflows(updated)
      // In a real implementation, delete from Google Sheets
      localStorage.setItem('workflows', JSON.stringify(updated))
    }
  }

  if (loading) {
    return (
      <div className="workflows-page">
        <div className="loading-state" role="status" aria-live="polite">
          <p>Loading workflows...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="workflows-page">
      <header className="workflows-header">
        <h1>My Workflows</h1>
        <p className="workflows-intro">
          Manage and execute your saved automation workflows.
        </p>
      </header>

      {workflows.length === 0 ? (
        <div className="empty-state" role="status" aria-live="polite">
          <p className="empty-message">No workflows yet. Create your first workflow using the wizard!</p>
          <a href="/wizard" className="btn btn-primary">
            Create Workflow
          </a>
        </div>
      ) : (
        <>
          <div className="workflows-controls">
            <label htmlFor="workflow-filter" className="sr-only">
              Filter workflows
            </label>
            <select
              id="workflow-filter"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="workflow-filter"
              aria-label="Filter workflows by status"
            >
              <option value="all">All Workflows</option>
              <option value="active">Active</option>
              <option value="paused">Paused</option>
              <option value="completed">Completed</option>
            </select>
          </div>

          <div className="workflows-grid" role="list" aria-label="Saved workflows">
            {filteredWorkflows.map(workflow => (
              <div
                key={workflow.id}
                className="workflow-card"
                role="listitem"
              >
                <div className="workflow-header">
                  <h3 className="workflow-name">{workflow.name || 'Unnamed Workflow'}</h3>
                  <span className={`workflow-status ${workflow.status || 'active'}`}>
                    {workflow.status || 'active'}
                  </span>
                </div>
                
                <div className="workflow-details">
                  <div className="workflow-detail">
                    <span className="detail-label">Type:</span>
                    <span className="detail-value">{workflow.type || 'N/A'}</span>
                  </div>
                  {workflow.createdAt && (
                    <div className="workflow-detail">
                      <span className="detail-label">Created:</span>
                      <span className="detail-value">
                        {new Date(workflow.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  )}
                  {workflow.steps && (
                    <div className="workflow-detail">
                      <span className="detail-label">Steps:</span>
                      <span className="detail-value">{workflow.steps.length}</span>
                    </div>
                  )}
                </div>

                <div className="workflow-actions">
                  <button
                    className="workflow-btn workflow-btn-primary"
                    onClick={() => handleExecute(workflow.id)}
                    aria-label={`Execute workflow: ${workflow.name}`}
                  >
                    Run
                  </button>
                  <button
                    className="workflow-btn workflow-btn-secondary"
                    onClick={() => handleDelete(workflow.id)}
                    aria-label={`Delete workflow: ${workflow.name}`}
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}

export default Workflows

