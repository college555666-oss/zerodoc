import { useState, useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { useSheets } from '../utils/sheets'
import AccessibilityPreview from '../components/AccessibilityPreview'
import MultiChannelAlerts from '../components/MultiChannelAlerts'
import './Wizard.css'

const WIZARD_STEPS = [
  {
    id: 'name',
    title: 'Workflow Name',
    question: 'What would you like to name this workflow?',
    type: 'text',
    required: true
  },
  {
    id: 'type',
    title: 'Workflow Type',
    question: 'What type of automation do you want to create?',
    type: 'select',
    options: [
      { value: 'form-autofill', label: 'Form Autofill' },
      { value: 'alert', label: 'Alert/Notification' },
      { value: 'data-collection', label: 'Data Collection' },
      { value: 'reminder', label: 'Reminder' },
      { value: 'monitor', label: 'Content Monitor' }
    ],
    required: true
  },
  {
    id: 'target',
    title: 'Target Website',
    question: 'What website or URL should this workflow target?',
    type: 'url',
    required: true,
    placeholder: 'https://example.com'
  },
  {
    id: 'trigger',
    title: 'Trigger',
    question: 'When should this workflow run?',
    type: 'select',
    options: [
      { value: 'manual', label: 'Manual (I will start it)' },
      { value: 'scheduled', label: 'Scheduled (at specific times)' },
      { value: 'page-load', label: 'When page loads' },
      { value: 'button-click', label: 'When button is clicked' }
    ],
    required: true
  },
  {
    id: 'actions',
    title: 'Actions',
    question: 'What should this workflow do?',
    type: 'multiselect',
    options: [
      { value: 'fill-form', label: 'Fill form fields' },
      { value: 'click-button', label: 'Click button' },
      { value: 'extract-data', label: 'Extract data' },
      { value: 'send-alert', label: 'Send alert/notification' }
    ],
    required: true
  },
  {
    id: 'alerts',
    title: 'Notifications',
    question: 'How would you like to receive notifications?',
    type: 'custom',
    component: 'MultiChannelAlerts',
    required: false
  },
  {
    id: 'review',
    title: 'Review',
    question: 'Review your workflow settings',
    type: 'review',
    required: false
  }
]

function Wizard({ privacyMode, accessibilityMode }) {
  const [currentStep, setCurrentStep] = useState(0)
  const [formData, setFormData] = useState({})
  const [errors, setErrors] = useState({})
  const [searchParams] = useSearchParams()
  const navigate = useNavigate()
  const { saveWorkflow } = useSheets()

  useEffect(() => {
    // Pre-fill template if provided
    const templateId = searchParams.get('template')
    if (templateId) {
      setFormData(prev => ({
        ...prev,
        type: templateId,
        name: templateId.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')
      }))
    }
  }, [searchParams])

  const currentStepData = WIZARD_STEPS[currentStep]

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev }
        delete newErrors[field]
        return newErrors
      })
    }
  }

  const validateStep = () => {
    const step = currentStepData
    if (step.required && !formData[step.id]) {
      setErrors(prev => ({
        ...prev,
        [step.id]: 'This field is required'
      }))
      return false
    }
    return true
  }

  const handleNext = () => {
    if (validateStep()) {
      if (currentStep < WIZARD_STEPS.length - 1) {
        setCurrentStep(currentStep + 1)
        // Scroll to top for accessibility
        window.scrollTo({ top: 0, behavior: 'smooth' })
      } else {
        handleSubmit()
      }
    }
  }

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
      window.scrollTo({ top: 0, behavior: 'smooth' })
    }
  }

  const handleSubmit = async () => {
    try {
      await saveWorkflow({
        name: formData.name,
        type: formData.type,
        target: formData.target,
        trigger: formData.trigger,
        actions: formData.actions || [],
        alerts: formData.alerts || {},
        steps: Object.entries(formData).map(([key, value]) => ({
          step: key,
          value
        }))
      })
      
      alert('Workflow created successfully!')
      navigate('/workflows')
    } catch (error) {
      console.error('Error saving workflow:', error)
      alert('Failed to save workflow. Please try again.')
    }
  }

  const renderStepContent = () => {
    const step = currentStepData

    if (step.type === 'text') {
      return (
        <div className="wizard-input-group">
          <label htmlFor={step.id} className="wizard-label">
            {step.question}
          </label>
          <input
            id={step.id}
            type="text"
            value={formData[step.id] || ''}
            onChange={(e) => handleInputChange(step.id, e.target.value)}
            className={`wizard-input ${errors[step.id] ? 'error' : ''}`}
            aria-describedby={errors[step.id] ? `${step.id}-error` : undefined}
            aria-required={step.required}
            autoFocus
          />
          {errors[step.id] && (
            <div id={`${step.id}-error`} className="wizard-error" role="alert">
              {errors[step.id]}
            </div>
          )}
        </div>
      )
    }

    if (step.type === 'url') {
      return (
        <div className="wizard-input-group">
          <label htmlFor={step.id} className="wizard-label">
            {step.question}
          </label>
          <input
            id={step.id}
            type="url"
            value={formData[step.id] || ''}
            onChange={(e) => handleInputChange(step.id, e.target.value)}
            placeholder={step.placeholder}
            className={`wizard-input ${errors[step.id] ? 'error' : ''}`}
            aria-describedby={errors[step.id] ? `${step.id}-error` : undefined}
            aria-required={step.required}
            autoFocus
          />
          {errors[step.id] && (
            <div id={`${step.id}-error`} className="wizard-error" role="alert">
              {errors[step.id]}
            </div>
          )}
        </div>
      )
    }

    if (step.type === 'select') {
      return (
        <div className="wizard-input-group">
          <label htmlFor={step.id} className="wizard-label">
            {step.question}
          </label>
          <select
            id={step.id}
            value={formData[step.id] || ''}
            onChange={(e) => handleInputChange(step.id, e.target.value)}
            className={`wizard-select ${errors[step.id] ? 'error' : ''}`}
            aria-describedby={errors[step.id] ? `${step.id}-error` : undefined}
            aria-required={step.required}
            autoFocus
          >
            <option value="">Select an option...</option>
            {step.options.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
          {errors[step.id] && (
            <div id={`${step.id}-error`} className="wizard-error" role="alert">
              {errors[step.id]}
            </div>
          )}
        </div>
      )
    }

    if (step.type === 'multiselect') {
      return (
        <div className="wizard-input-group">
          <fieldset>
            <legend className="wizard-label">{step.question}</legend>
            <div className="checkbox-group">
              {step.options.map(option => (
                <label key={option.value} className="checkbox-label">
                  <input
                    type="checkbox"
                    value={option.value}
                    checked={(formData[step.id] || []).includes(option.value)}
                    onChange={(e) => {
                      const current = formData[step.id] || []
                      const updated = e.target.checked
                        ? [...current, option.value]
                        : current.filter(v => v !== option.value)
                      handleInputChange(step.id, updated)
                    }}
                    aria-required={step.required}
                  />
                  <span>{option.label}</span>
                </label>
              ))}
            </div>
            {errors[step.id] && (
              <div id={`${step.id}-error`} className="wizard-error" role="alert">
                {errors[step.id]}
              </div>
            )}
          </fieldset>
        </div>
      )
    }

    if (step.type === 'custom' && step.component === 'MultiChannelAlerts') {
      return (
        <div className="wizard-input-group">
          <label className="wizard-label">{step.question}</label>
          <MultiChannelAlerts
            value={formData.alerts || {}}
            onChange={(alerts) => handleInputChange('alerts', alerts)}
          />
        </div>
      )
    }

    if (step.type === 'review') {
      return (
        <div className="wizard-review">
          <h3>Review Your Workflow</h3>
          <dl className="review-list">
            {WIZARD_STEPS.slice(0, -1).map(s => (
              <div key={s.id} className="review-item">
                <dt>{s.title}:</dt>
                <dd>
                  {Array.isArray(formData[s.id])
                    ? formData[s.id].join(', ')
                    : typeof formData[s.id] === 'object'
                    ? JSON.stringify(formData[s.id])
                    : formData[s.id] || 'Not set'}
                </dd>
              </div>
            ))}
          </dl>
        </div>
      )
    }

    return null
  }

  return (
    <div className="wizard-page">
      <header className="wizard-header">
        <h1>Create New Workflow</h1>
        <p className="wizard-progress">
          Step {currentStep + 1} of {WIZARD_STEPS.length}
        </p>
        <div className="wizard-progress-bar" role="progressbar" aria-valuenow={currentStep + 1} aria-valuemin="1" aria-valuemax={WIZARD_STEPS.length}>
          <div 
            className="wizard-progress-fill"
            style={{ width: `${((currentStep + 1) / WIZARD_STEPS.length) * 100}%` }}
          ></div>
        </div>
      </header>

      <div className="wizard-content">
        <div className="wizard-step">
          <h2 id="wizard-step-title">{currentStepData.title}</h2>
          <p className="wizard-question" id="wizard-step-question">
            {currentStepData.question}
          </p>
          
          {renderStepContent()}

          {accessibilityMode && (
            <AccessibilityPreview 
              step={currentStepData}
              formData={formData}
            />
          )}
        </div>

        <div className="wizard-actions">
          <button
            className="wizard-btn wizard-btn-secondary"
            onClick={handleBack}
            disabled={currentStep === 0}
            aria-label="Go to previous step"
          >
            ← Back
          </button>
          <button
            className="wizard-btn wizard-btn-primary"
            onClick={handleNext}
            aria-label={currentStep === WIZARD_STEPS.length - 1 ? 'Save workflow' : 'Go to next step'}
          >
            {currentStep === WIZARD_STEPS.length - 1 ? 'Save Workflow' : 'Next →'}
          </button>
        </div>
      </div>
    </div>
  )
}

export default Wizard

