import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useSheets } from '../utils/sheets'
import './Templates.css'

const TEMPLATES = [
  {
    id: 'form-autofill',
    name: 'Form Autofill',
    description: 'Automatically fill out web forms with your saved data',
    icon: '📝',
    category: 'Forms'
  },
  {
    id: 'alert-notification',
    name: 'Alert Notification',
    description: 'Send alerts via email, SMS, or in-app when specific conditions are met',
    icon: '🔔',
    category: 'Notifications'
  },
  {
    id: 'data-collection',
    name: 'Data Collection',
    description: 'Collect and store data from websites to your Google Sheet',
    icon: '📊',
    category: 'Data'
  },
  {
    id: 'reminder-system',
    name: 'Reminder System',
    description: 'Set up automated reminders for important tasks or deadlines',
    icon: '⏰',
    category: 'Productivity'
  },
  {
    id: 'content-monitor',
    name: 'Content Monitor',
    description: 'Monitor websites for changes and get notified when content updates',
    icon: '👁️',
    category: 'Monitoring'
  },
  {
    id: 'multi-step-workflow',
    name: 'Multi-Step Workflow',
    description: 'Create complex workflows with multiple steps and conditions',
    icon: '🔄',
    category: 'Advanced'
  }
]

function Templates() {
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [searchQuery, setSearchQuery] = useState('')
  const navigate = useNavigate()
  const { saveTemplateUsage } = useSheets()

  const categories = ['All', ...new Set(TEMPLATES.map(t => t.category))]

  const filteredTemplates = TEMPLATES.filter(template => {
    const matchesCategory = selectedCategory === 'All' || template.category === selectedCategory
    const matchesSearch = template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesCategory && matchesSearch
  })

  const handleTemplateSelect = async (templateId) => {
    // Save template usage to Google Sheets
    await saveTemplateUsage(templateId)
    
    // Navigate to wizard with template pre-selected
    navigate(`/wizard?template=${templateId}`)
  }

  return (
    <div className="templates-page">
      <header className="templates-header">
        <h1>Automation Templates</h1>
        <p className="templates-intro">
          Choose a pre-made template to get started quickly, or customize it to fit your needs.
        </p>
      </header>

      <div className="templates-controls">
        <div className="search-container">
          <label htmlFor="template-search" className="sr-only">
            Search templates
          </label>
          <input
            id="template-search"
            type="search"
            placeholder="Search templates..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-input"
            aria-label="Search templates"
          />
        </div>

        <div className="category-filter">
          <label htmlFor="category-select" className="sr-only">
            Filter by category
          </label>
          <select
            id="category-select"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="category-select"
            aria-label="Filter templates by category"
          >
            {categories.map(category => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="templates-grid" role="list" aria-label="Automation templates">
        {filteredTemplates.length === 0 ? (
          <div className="no-results" role="status" aria-live="polite">
            <p>No templates found matching your search.</p>
          </div>
        ) : (
          filteredTemplates.map(template => (
            <div
              key={template.id}
              className="template-card"
              role="listitem"
            >
              <div className="template-icon" aria-hidden="true">
                {template.icon}
              </div>
              <div className="template-category">{template.category}</div>
              <h3 className="template-name">{template.name}</h3>
              <p className="template-description">{template.description}</p>
              <button
                className="template-select-btn"
                onClick={() => handleTemplateSelect(template.id)}
                aria-label={`Select ${template.name} template`}
              >
                Use This Template
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  )
}

export default Templates

