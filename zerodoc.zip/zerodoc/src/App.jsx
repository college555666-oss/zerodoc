import { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom'
import Home from './pages/Home'
import Wizard from './pages/Wizard'
import Templates from './pages/Templates'
import Workflows from './pages/Workflows'
import PrivacyToggle from './components/PrivacyToggle'
import VoiceCommands from './components/VoiceCommands'
import AccessibilityFeedback from './components/AccessibilityFeedback'
import './App.css'

function Navigation() {
  const location = useLocation()
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const navLinks = [
    { path: '/', label: 'Home', ariaLabel: 'Go to home page' },
    { path: '/templates', label: 'Templates', ariaLabel: 'Browse automation templates' },
    { path: '/wizard', label: 'Create Workflow', ariaLabel: 'Create a new workflow using the wizard' },
    { path: '/workflows', label: 'My Workflows', ariaLabel: 'View your saved workflows' },
  ]

  return (
    <nav role="navigation" aria-label="Main navigation">
      <div className="nav-container">
        <Link to="/" className="logo" aria-label="ZeroCode Automate home">
          <h1>ZeroCode Automate</h1>
        </Link>
        
        <button
          className="menu-toggle"
          aria-label="Toggle navigation menu"
          aria-expanded={isMenuOpen}
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          <span className="sr-only">Menu</span>
          <span aria-hidden="true">☰</span>
        </button>

        <ul className={`nav-links ${isMenuOpen ? 'open' : ''}`}>
          {navLinks.map((link) => (
            <li key={link.path}>
              <Link
                to={link.path}
                className={location.pathname === link.path ? 'active' : ''}
                aria-label={link.ariaLabel}
                onClick={() => setIsMenuOpen(false)}
              >
                {link.label}
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </nav>
  )
}

function App() {
  const [privacyMode, setPrivacyMode] = useState(false)
  const [accessibilityMode, setAccessibilityMode] = useState(false)

  useEffect(() => {
    // Load privacy mode preference from localStorage
    const savedPrivacyMode = localStorage.getItem('privacyMode') === 'true'
    setPrivacyMode(savedPrivacyMode)
  }, [])

  return (
    <Router>
      <div className="app">
        <a href="#main-content" className="skip-link">
          Skip to main content
        </a>
        <Navigation />
        <div className="app-controls">
          <PrivacyToggle 
            privacyMode={privacyMode} 
            setPrivacyMode={setPrivacyMode} 
          />
          <button
            className="accessibility-toggle"
            onClick={() => setAccessibilityMode(!accessibilityMode)}
            aria-label={accessibilityMode ? 'Disable accessibility mode' : 'Enable accessibility mode'}
            aria-pressed={accessibilityMode}
          >
            {accessibilityMode ? '🔊 Accessibility On' : '🔇 Accessibility Off'}
          </button>
        </div>
        <AccessibilityFeedback />
        <VoiceCommands />
        <main id="main-content" role="main">
          <Routes>
            <Route path="/" element={<Home accessibilityMode={accessibilityMode} />} />
            <Route path="/templates" element={<Templates />} />
            <Route path="/wizard" element={<Wizard privacyMode={privacyMode} accessibilityMode={accessibilityMode} />} />
            <Route path="/workflows" element={<Workflows privacyMode={privacyMode} />} />
          </Routes>
        </main>
        <footer role="contentinfo">
          <p>
            ZeroCode Automate - Making web automation accessible to everyone.
            Built with accessibility and privacy in mind.
          </p>
        </footer>
      </div>
    </Router>
  )
}

export default App

