import { useState } from 'react'
import './MultiChannelAlerts.css'

function MultiChannelAlerts({ value = {}, onChange }) {
  const [channels, setChannels] = useState({
    email: value.email || false,
    sms: value.sms || false,
    inApp: value.inApp !== false // default to true
  })

  const [emailAddress, setEmailAddress] = useState(value.emailAddress || '')
  const [phoneNumber, setPhoneNumber] = useState(value.phoneNumber || '')

  const handleChannelToggle = (channel) => {
    const updated = {
      ...channels,
      [channel]: !channels[channel]
    }
    setChannels(updated)
    onChange({
      ...updated,
      emailAddress: updated.email ? emailAddress : '',
      phoneNumber: updated.sms ? phoneNumber : ''
    })
  }

  const handleEmailChange = (e) => {
    const email = e.target.value
    setEmailAddress(email)
    onChange({
      ...channels,
      emailAddress: email,
      phoneNumber
    })
  }

  const handlePhoneChange = (e) => {
    const phone = e.target.value
    setPhoneNumber(phone)
    onChange({
      ...channels,
      emailAddress,
      phoneNumber: phone
    })
  }

  return (
    <div className="multi-channel-alerts" role="group" aria-labelledby="alert-channels-label">
      <p id="alert-channels-label" className="alerts-intro">
        Select one or more notification channels:
      </p>

      <div className="alert-channels">
        <label className="channel-option">
          <input
            type="checkbox"
            checked={channels.inApp}
            onChange={() => handleChannelToggle('inApp')}
            aria-describedby="inapp-description"
          />
          <div className="channel-content">
            <span className="channel-name">In-App Notification</span>
            <span id="inapp-description" className="channel-description">
              Accessible popup notifications within the application
            </span>
          </div>
        </label>

        <label className="channel-option">
          <input
            type="checkbox"
            checked={channels.email}
            onChange={() => handleChannelToggle('email')}
            aria-describedby="email-description"
          />
          <div className="channel-content">
            <span className="channel-name">Email</span>
            <span id="email-description" className="channel-description">
              Receive notifications via email
            </span>
          </div>
        </label>

        {channels.email && (
          <div className="channel-input-group">
            <label htmlFor="email-address" className="channel-input-label">
              Email Address
            </label>
            <input
              id="email-address"
              type="email"
              value={emailAddress}
              onChange={handleEmailChange}
              placeholder="your.email@example.com"
              className="channel-input"
              aria-required={channels.email}
            />
          </div>
        )}

        <label className="channel-option">
          <input
            type="checkbox"
            checked={channels.sms}
            onChange={() => handleChannelToggle('sms')}
            aria-describedby="sms-description"
          />
          <div className="channel-content">
            <span className="channel-name">SMS</span>
            <span id="sms-description" className="channel-description">
              Receive text message notifications
            </span>
          </div>
        </label>

        {channels.sms && (
          <div className="channel-input-group">
            <label htmlFor="phone-number" className="channel-input-label">
              Phone Number
            </label>
            <input
              id="phone-number"
              type="tel"
              value={phoneNumber}
              onChange={handlePhoneChange}
              placeholder="+1 (555) 123-4567"
              className="channel-input"
              aria-required={channels.sms}
            />
          </div>
        )}
      </div>

      <div className="alerts-note" role="note">
        <p>
          <strong>Note:</strong> All notification channels are designed to be accessible.
          In-app notifications support screen readers, and email/SMS formats are optimized for assistive technologies.
        </p>
      </div>
    </div>
  )
}

export default MultiChannelAlerts

