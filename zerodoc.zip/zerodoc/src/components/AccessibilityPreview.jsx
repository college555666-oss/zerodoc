import { useState } from 'react'
import './AccessibilityPreview.css'

function AccessibilityPreview({ step, formData }) {
  const [previewMode, setPreviewMode] = useState('screen-reader') // 'screen-reader' | 'keyboard' | 'high-contrast'

  const getScreenReaderText = () => {
    let text = `Step: ${step.title}. ${step.question}. `
    
    if (step.type === 'text' || step.type === 'url') {
      text += `Text input field. ${formData[step.id] ? `Current value: ${formData[step.id]}` : 'No value entered'}.`
    } else if (step.type === 'select') {
      const selected = step.options?.find(opt => opt.value === formData[step.id])
      text += `Dropdown menu. ${selected ? `Selected: ${selected.label}` : 'No option selected'}.`
    } else if (step.type === 'multiselect') {
      const selected = (formData[step.id] || []).map(val => 
        step.options?.find(opt => opt.value === val)?.label
      ).filter(Boolean)
      text += `Checkbox group. ${selected.length > 0 ? `Selected: ${selected.join(', ')}` : 'No options selected'}.`
    }
    
    return text
  }

  const getKeyboardNavigationInfo = () => {
    return [
      'Use Tab to move between form fields',
      'Use Shift+Tab to move backwards',
      'Use Enter or Space to activate buttons',
      'Use Arrow keys to navigate dropdowns and checkboxes',
      'Use Escape to close dialogs'
    ]
  }

  return (
    <div className="accessibility-preview" role="region" aria-label="Accessibility preview">
      <div className="preview-header">
        <h3>Accessibility Preview</h3>
        <div className="preview-mode-selector">
          <label htmlFor="preview-mode" className="sr-only">Preview mode</label>
          <select
            id="preview-mode"
            value={previewMode}
            onChange={(e) => setPreviewMode(e.target.value)}
            aria-label="Select accessibility preview mode"
          >
            <option value="screen-reader">Screen Reader</option>
            <option value="keyboard">Keyboard Navigation</option>
            <option value="high-contrast">High Contrast</option>
          </select>
        </div>
      </div>

      <div className="preview-content">
        {previewMode === 'screen-reader' && (
          <div className="preview-screen-reader">
            <h4>Screen Reader Output</h4>
            <div className="screen-reader-text" role="status" aria-live="polite">
              {getScreenReaderText()}
            </div>
            <p className="preview-note">
              This is what a screen reader would announce to users.
            </p>
          </div>
        )}

        {previewMode === 'keyboard' && (
          <div className="preview-keyboard">
            <h4>Keyboard Navigation Guide</h4>
            <ul className="keyboard-shortcuts">
              {getKeyboardNavigationInfo().map((info, index) => (
                <li key={index}>{info}</li>
              ))}
            </ul>
            <p className="preview-note">
              All interactive elements are accessible via keyboard only.
            </p>
          </div>
        )}

        {previewMode === 'high-contrast' && (
          <div className="preview-high-contrast">
            <h4>High Contrast Mode</h4>
            <div className="high-contrast-demo">
              <p>
                In high contrast mode, colors are adjusted for maximum visibility.
                This preview shows how the interface appears to users with high contrast preferences.
              </p>
              <div className="contrast-example">
                <div className="contrast-item">Text on Background</div>
                <div className="contrast-item-alt">Alternative Text</div>
              </div>
            </div>
            <p className="preview-note">
              The interface adapts to your system's high contrast settings.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}

export default AccessibilityPreview

