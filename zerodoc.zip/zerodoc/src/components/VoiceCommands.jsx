import { useState, useEffect, useRef } from 'react'
import './VoiceCommands.css'

function VoiceCommands() {
  const [isListening, setIsListening] = useState(false)
  const [transcript, setTranscript] = useState('')
  const [isSupported, setIsSupported] = useState(false)
  const recognitionRef = useRef(null)

  useEffect(() => {
    // Check if Web Speech API is supported
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    
    if (SpeechRecognition) {
      setIsSupported(true)
      const recognition = new SpeechRecognition()
      recognition.continuous = false
      recognition.interimResults = false
      recognition.lang = 'en-US'

      recognition.onstart = () => {
        setIsListening(true)
      }

      recognition.onresult = (event) => {
        const last = event.results.length - 1
        const text = event.results[last][0].transcript
        setTranscript(text)
        handleVoiceCommand(text.toLowerCase())
      }

      recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error)
        setIsListening(false)
        if (event.error === 'not-allowed') {
          alert('Microphone permission denied. Please enable microphone access in your browser settings.')
        }
      }

      recognition.onend = () => {
        setIsListening(false)
      }

      recognitionRef.current = recognition
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
    }
  }, [])

  const handleVoiceCommand = (command) => {
    // Simple command recognition
    if (command.includes('start') || command.includes('run') || command.includes('execute')) {
      // Trigger workflow execution
      const event = new CustomEvent('voiceExecuteWorkflow')
      window.dispatchEvent(event)
    } else if (command.includes('stop') || command.includes('cancel')) {
      // Stop current operation
      const event = new CustomEvent('voiceStopWorkflow')
      window.dispatchEvent(event)
    } else if (command.includes('help')) {
      // Show help
      alert('Voice commands: "start workflow", "stop workflow", "help"')
    }
  }

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      try {
        recognitionRef.current.start()
      } catch (error) {
        console.error('Error starting recognition:', error)
      }
    }
  }

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop()
    }
  }

  if (!isSupported) {
    return (
      <div className="voice-commands-unavailable" role="status" aria-live="polite">
        <p>Voice commands are not supported in your browser.</p>
      </div>
    )
  }

  return (
    <div className="voice-commands-container" role="region" aria-label="Voice command controls">
      <button
        className={`voice-command-button ${isListening ? 'listening' : ''}`}
        onClick={isListening ? stopListening : startListening}
        aria-label={isListening ? 'Stop listening' : 'Start voice command'}
        aria-pressed={isListening}
      >
        <span className="voice-icon" aria-hidden="true">
          {isListening ? '🛑' : '🎤'}
        </span>
        <span className="voice-text">
          {isListening ? 'Listening...' : 'Voice Command'}
        </span>
      </button>
      
      {transcript && (
        <div 
          className="voice-transcript"
          role="status"
          aria-live="polite"
          aria-atomic="true"
        >
          <p><strong>You said:</strong> {transcript}</p>
        </div>
      )}

      <div className="voice-help" role="region" aria-label="Voice command help">
        <details>
          <summary>Voice Commands Help</summary>
          <ul>
            <li>"Start workflow" or "Run workflow" - Execute the current workflow</li>
            <li>"Stop workflow" or "Cancel" - Stop the current operation</li>
            <li>"Help" - Show this help message</li>
          </ul>
        </details>
      </div>
    </div>
  )
}

export default VoiceCommands

