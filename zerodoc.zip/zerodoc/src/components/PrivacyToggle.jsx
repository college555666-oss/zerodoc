import { useState, useEffect } from 'react'
import './PrivacyToggle.css'

function PrivacyToggle({ privacyMode, setPrivacyMode }) {
  const [showInfo, setShowInfo] = useState(false)

  const handleToggle = () => {
    const newMode = !privacyMode
    setPrivacyMode(newMode)
    localStorage.setItem('privacyMode', newMode.toString())
  }

  return (
    <div className="privacy-toggle-container">
      <div className="privacy-toggle-wrapper">
        <label htmlFor="privacy-toggle" className="privacy-label">
          <span className="privacy-label-text">Privacy Mode</span>
          <button
            id="privacy-toggle"
            type="button"
            role="switch"
            aria-checked={privacyMode}
            aria-label={privacyMode ? 'Privacy mode enabled' : 'Privacy mode disabled'}
            className={`privacy-toggle ${privacyMode ? 'active' : ''}`}
            onClick={handleToggle}
          >
            <span className="toggle-slider" aria-hidden="true"></span>
          </button>
        </label>
        <button
          className="privacy-info-button"
          aria-label="Learn more about privacy mode"
          onClick={() => setShowInfo(!showInfo)}
          aria-expanded={showInfo}
        >
          ℹ️
        </button>
      </div>
      
      {showInfo && (
        <div 
          className="privacy-info"
          role="region"
          aria-labelledby="privacy-info-heading"
        >
          <h3 id="privacy-info-heading">Privacy Mode</h3>
          <p>
            When enabled, Privacy Mode limits data collection and storage:
          </p>
          <ul>
            <li>Only essential workflow data is stored</li>
            <li>No analytics or usage tracking</li>
            <li>Data is encrypted before storage</li>
            <li>You can delete your data at any time</li>
          </ul>
          <p className="privacy-status">
            Current status: <strong>{privacyMode ? 'Enabled' : 'Disabled'}</strong>
          </p>
        </div>
      )}
    </div>
  )
}

export default PrivacyToggle

