import { useState, useEffect } from 'react'
import './AccessibilityFeedback.css'

function AccessibilityFeedback() {
  const [issues, setIssues] = useState([])
  const [isActive, setIsActive] = useState(true)

  useEffect(() => {
    if (!isActive) return

    const checkAccessibility = () => {
      const newIssues = []

      // Check for images without alt text
      const images = document.querySelectorAll('img')
      images.forEach((img, index) => {
        if (!img.alt && !img.getAttribute('aria-hidden')) {
          newIssues.push({
            id: `img-${index}`,
            type: 'error',
            message: `Image missing alt text: ${img.src.substring(img.src.lastIndexOf('/') + 1)}`,
            element: img,
            fix: 'Add an alt attribute describing the image content'
          })
        }
      })

      // Check for buttons without accessible labels
      const buttons = document.querySelectorAll('button')
      buttons.forEach((button, index) => {
        const hasLabel = button.textContent.trim() || 
                        button.getAttribute('aria-label') || 
                        button.getAttribute('aria-labelledby')
        if (!hasLabel && !button.getAttribute('aria-hidden')) {
          newIssues.push({
            id: `btn-${index}`,
            type: 'warning',
            message: 'Button missing accessible label',
            element: button,
            fix: 'Add text content or an aria-label attribute'
          })
        }
      })

      // Check for form inputs without labels
      const inputs = document.querySelectorAll('input, textarea, select')
      inputs.forEach((input, index) => {
        const id = input.id
        const hasLabel = id && document.querySelector(`label[for="${id}"]`) ||
                        input.getAttribute('aria-label') ||
                        input.getAttribute('aria-labelledby') ||
                        input.closest('label')
        if (!hasLabel && !input.getAttribute('aria-hidden')) {
          newIssues.push({
            id: `input-${index}`,
            type: 'error',
            message: `Form input missing label: ${input.type || 'input'}`,
            element: input,
            fix: 'Add a label element or aria-label attribute'
          })
        }
      })

      // Check for missing heading hierarchy
      const headings = document.querySelectorAll('h1, h2, h3, h4, h5, h6')
      let lastLevel = 0
      headings.forEach((heading, index) => {
        const level = parseInt(heading.tagName.charAt(1))
        if (level > lastLevel + 1 && lastLevel > 0) {
          newIssues.push({
            id: `heading-${index}`,
            type: 'warning',
            message: `Heading level skipped: ${heading.tagName} after h${lastLevel}`,
            element: heading,
            fix: 'Maintain proper heading hierarchy (h1 → h2 → h3, etc.)'
          })
        }
        lastLevel = level
      })

      setIssues(newIssues)
    }

    // Run initial check
    checkAccessibility()

    // Set up observer for dynamic content
    const observer = new MutationObserver(checkAccessibility)
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['alt', 'aria-label', 'aria-labelledby']
    })

    return () => observer.disconnect()
  }, [isActive])

  if (!isActive || issues.length === 0) {
    return null
  }

  return (
    <div 
      className="accessibility-feedback"
      role="region"
      aria-label="Accessibility feedback"
      aria-live="polite"
    >
      <div className="feedback-header">
        <h3>Accessibility Feedback</h3>
        <button
          className="feedback-close"
          onClick={() => setIsActive(false)}
          aria-label="Close accessibility feedback"
        >
          ×
        </button>
      </div>
      <div className="feedback-issues">
        {issues.slice(0, 5).map((issue) => (
          <div
            key={issue.id}
            className={`feedback-issue ${issue.type}`}
            role="alert"
          >
            <div className="issue-icon" aria-hidden="true">
              {issue.type === 'error' ? '⚠️' : 'ℹ️'}
            </div>
            <div className="issue-content">
              <p className="issue-message">{issue.message}</p>
              <p className="issue-fix">
                <strong>Fix:</strong> {issue.fix}
              </p>
            </div>
          </div>
        ))}
        {issues.length > 5 && (
          <p className="feedback-more">
            {issues.length - 5} more issue{issues.length - 5 !== 1 ? 's' : ''} found
          </p>
        )}
      </div>
    </div>
  )
}

export default AccessibilityFeedback

